This package provides `smart-compile' function.
You can associates a particular file with a particular compile functions,
by editing `smart-compile-alist'.

To use this package, add these lines to your .emacs file:
    (require 'smart-compile)

Note that it requires emacs 21 or later.
