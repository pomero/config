require outline-magic.el by CarstenDominik found here:
http://www.astro.uva.nl/~dominik/Tools/outline-magic.el
code taken from:
http://stackoverflow.com/a/4093889
modified code here by Nikwin slightly found here:
http://stackoverflow.com/a/1085551
