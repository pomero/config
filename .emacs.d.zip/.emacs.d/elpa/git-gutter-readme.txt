Port of GitGutter which is a plugin of Sublime Text
