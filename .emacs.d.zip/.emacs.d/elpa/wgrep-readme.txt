wgrep allows you to edit a grep buffer and apply those changes to
the file buffer.
